package cmpt213.assignment4.packagedeliveries.webappserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebAppServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
